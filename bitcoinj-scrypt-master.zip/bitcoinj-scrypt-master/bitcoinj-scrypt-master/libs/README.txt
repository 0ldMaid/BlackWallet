Each directory contains the native shared libraries for the Kimoto Gravity Well optimizations.

